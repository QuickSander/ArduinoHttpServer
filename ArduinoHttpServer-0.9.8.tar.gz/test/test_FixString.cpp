//
//! \file
//  Unit test for FixString
//
//  Created by Sander van Woensel on 02-10-18.
//  Copyright (c) 2018 Sander van Woensel. All rights reserved.
//

// This is work in progress.

#include "../src/internals/FixString.hpp"

//
// void testFixStringSubString(void)
// {
//     TEST_ASSERT_EQUAL(1,1);
// }
//
// void process()
// {
//     UNITY_BEGIN();
//     RUN_TEST(testFixStringSubString);
//     UNITY_END();
// }
//
int main(int argc, char **argv)
{
    //process();
    return 0;
}
